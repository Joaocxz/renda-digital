# RENDA DIGITAL — Guia rápido de edição e publicação

Site de apresentação e vendas do ebook **RENDA DIGITAL** (HTML5 + CSS3 + JavaScript puro, sem dependências).

---

## 1. Estrutura de arquivos

```
renda-digital-site/
├── index.html                  → Página principal (landing page completa)
├── css/
│   └── styles.css              → Todo o visual do site (cores, fontes, layout)
├── js/
│   ├── config.js               → CONFIGURAÇÃO PRINCIPAL (edite aqui primeiro)
│   └── main.js                 → Interações (menu, FAQ, animações)
├── politicas/
│   ├── privacidade.html        → Política de Privacidade (modelo a preencher)
│   ├── termos-de-uso.html      → Termos de Uso (modelo a preencher)
│   └── reembolso.html          → Política de Reembolso (modelo a preencher)
└── LEIA-ME.md                  → Este guia
```

## 2. Configuração obrigatória antes de publicar

### a) Link de checkout (js/config.js)

Abra `js/config.js` e cole o link real da sua plataforma de pagamento
(Hotmart, Kiwify, Eduzz, Monetizze etc.) na variável `CHECKOUT_URL`:

```js
const CHECKOUT_URL = "https://pay.suaplataforma.com/seu-produto";
```

Todos os botões de compra do site ("COMPRAR AGORA" e "ADQUIRIR MEU EBOOK")
passam a direcionar automaticamente para esse link, abrindo em nova aba.
Enquanto a variável estiver vazia, os botões exibem um aviso orientando a
configuração — nenhum checkout falso é criado.

### b) E-mail de suporte (js/config.js)

Preencha `SUPPORT_EMAIL` para exibi-lo automaticamente no rodapé:

```js
const SUPPORT_EMAIL = "suporte@seudominio.com.br";
```

### c) Dados do responsável (index.html e páginas de políticas)

Procure no `index.html` (rodapé) e nos arquivos da pasta `politicas/` pelos
marcadores `<!-- EDITE: ... -->` e pelos campos entre colchetes, como:

- `[e-mail de suporte]`
- `[canal de atendimento]`
- `[nome ou razão social do responsável]`
- `[EDITAR — dia/mês/ano]`

Preencha com os dados reais. Não utilize CNPJ, endereço ou informações
empresariais fictícias.

## 3. Personalização visual (css/styles.css)

No topo do arquivo `css/styles.css` estão as variáveis de cor e fontes:

```css
:root {
  --green: #00ff88;        /* verde neon de destaque */
  --bg-0: #050706;         /* fundo preto */
  --surface: #0d1210;      /* fundo dos cartões (grafite) */
  ...
}
```

Para trocar as cores do site inteiro, basta alterar essas variáveis.
As fontes atuais são **Sora** (títulos) e **Inter** (textos), carregadas do
Google Fonts no `<head>` do `index.html`.

## 4. Usar a imagem promocional oficial (opcional)

Os mockups 3D (ebook em notebook, tablet e celular) são criados em CSS puro —
leves e nítidos em qualquer tela. Se preferir usar a arte promocional oficial
do ebook, na seção "O produto" do `index.html` há um comentário `<!-- EDITE -->`
indicando onde inserir sua imagem:

```html
<img src="imagens/promo-oficial.png"
     alt="Mockup oficial do ebook Renda Digital"
     width="1200" height="600">
```

## 5. Como publicar

O site é 100% estático — pode ser hospedado em qualquer serviço:

| Serviço | Como publicar |
|---|---|
| **Hostinger / cPanel / FTP** | Envie o conteúdo da pasta para `public_html` |
| **Netlify / Vercel** | Arraste a pasta do site em "Deploy" |
| **GitHub Pages** | Envie os arquivos para um repositório e ative Pages |

Ao publicar em hospedagem compatível, o HTTPS é configurado pelo próprio
serviço (gratuito via Let's Encrypt na maioria deles). Sempre mantenha o site
acessível apenas via HTTPS.

Recomendações de segurança já aplicadas no código:
- Links de checkout abertos com `rel="noopener noreferrer"`;
- Nenhum dado de pagamento passa pelo site (processado pela plataforma);
- Sem JavaScript inline e sem chamadas externas além das fontes do Google.

## 6. Checklist antes de divulgar

- [ ] `CHECKOUT_URL` preenchida em `js/config.js`
- [ ] E-mail de suporte preenchido
- [ ] Campos `[...]` do rodapé e das políticas preenchidos com dados reais
- [ ] Teste de compra real realizado
- [ ] Link de canonial e Open Graph ajustados no `<head>` do `index.html`
