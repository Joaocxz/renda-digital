/* ============================================================
   RENDA DIGITAL — ARQUIVO DE CONFIGURAÇÃO
   ------------------------------------------------------------
   Este é o único arquivo que você precisa editar para
   configurar o site. Não é necessário mexer no HTML.
   ============================================================ */

/* 1) LINK DE CHECKOUT (obrigatório para receber pagamentos)
   ------------------------------------------------------------
   Cole entre as aspas o link da sua página de pagamento real
   (Hotmart, Kiwify, Eduzz, Monetizze, Stripe etc.).

   Exemplo:
   const CHECKOUT_URL = "https://pay.hotmart.com/A12345678B";
*/
const CHECKOUT_URL = "";

/* 2) E-MAIL DE SUPORTE (opcional)
   ------------------------------------------------------------
   Ao preencher, o e-mail aparece automaticamente no rodapé,
   na seção "Contato e suporte".

   Exemplo:
   const SUPPORT_EMAIL = "suporte@seudominio.com.br";
*/
const SUPPORT_EMAIL = "";

/* 3) ANO DOS DIREITOS AUTORAIS (opcional)
   ------------------------------------------------------------
   Deixe "" para exibir o ano atual automaticamente.
*/
const COPYRIGHT_YEAR = "";
