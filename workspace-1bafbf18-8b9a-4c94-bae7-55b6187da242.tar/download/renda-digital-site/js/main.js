/* ============================================================
   RENDA DIGITAL — Interações do site
   Menu mobile, link de checkout, FAQ (acordeão), animações
   de revelação, navegação ativa e avisos.
   ============================================================ */
(function () {
  "use strict";

  var $ = function (sel, ctx) {
    return (ctx || document).querySelector(sel);
  };
  var $$ = function (sel, ctx) {
    return Array.prototype.slice.call((ctx || document).querySelectorAll(sel));
  };

  /* ---------------- Toast (aviso flutuante) ---------------- */
  var toastTimer;

  function showToast(message) {
    var toast = $("#toast");
    if (!toast) {
      window.alert(message);
      return;
    }
    toast.textContent = message;
    toast.classList.add("show");
    clearTimeout(toastTimer);
    toastTimer = setTimeout(function () {
      toast.classList.remove("show");
    }, 4500);
  }

  /* ---------------- Link de checkout ----------------
     Os botões marcados com [data-checkout] recebem o valor
     de CHECKOUT_URL (definido em js/config.js).
     Enquanto estiver vazio, um aviso orientará a configurá-lo. */
  var checkoutUrl = typeof CHECKOUT_URL === "string" ? CHECKOUT_URL.trim() : "";
  var checkoutConfigured = checkoutUrl !== "";
  var buyButtons = $$("[data-checkout]");

  if (checkoutConfigured) {
    buyButtons.forEach(function (btn) {
      btn.setAttribute("href", checkoutUrl);
      btn.setAttribute("target", "_blank");
      btn.setAttribute("rel", "noopener noreferrer");
    });
  }

  buyButtons.forEach(function (btn) {
    btn.addEventListener("click", function (event) {
      if (!checkoutConfigured) {
        event.preventDefault();
        showToast(
          "O link de pagamento ainda não foi configurado. Edite a variável CHECKOUT_URL no arquivo js/config.js e cole o endereço do seu checkout."
        );
      }
    });
  });

  /* ---------------- Menu mobile ---------------- */
  var navToggle = $("#nav-toggle");
  var siteNav = $("#site-nav");

  function setMenu(openState) {
    document.body.classList.toggle("menu-open", openState);
    if (navToggle) {
      navToggle.setAttribute("aria-expanded", openState ? "true" : "false");
      navToggle.setAttribute(
        "aria-label",
        openState ? "Fechar menu de navegação" : "Abrir menu de navegação"
      );
    }
  }

  function closeMenu() {
    setMenu(false);
  }

  if (navToggle && siteNav) {
    navToggle.addEventListener("click", function () {
      setMenu(!document.body.classList.contains("menu-open"));
    });

    // Fecha o menu ao clicar em qualquer link
    $$("a", siteNav).forEach(function (link) {
      link.addEventListener("click", closeMenu);
    });

    // Fecha com a tecla Esc
    document.addEventListener("keydown", function (event) {
      if (event.key === "Escape") {
        closeMenu();
      }
    });

    // Fecha ao redimensionar para desktop
    window.addEventListener("resize", function () {
      if (window.innerWidth > 920) {
        closeMenu();
      }
    });
  }

  /* ---------------- Cabeçalho com sombra ao rolar ---------------- */
  var header = $(".site-header");

  function onScroll() {
    if (header) {
      header.classList.toggle("scrolled", window.scrollY > 8);
    }
  }

  window.addEventListener("scroll", onScroll, { passive: true });
  onScroll();

  /* ---------------- Link ativo na navegação ---------------- */
  var navLinks = $$(".nav-link");
  var sections = $$("main section[id]");

  if ("IntersectionObserver" in window && navLinks.length && sections.length) {
    var navObserver = new IntersectionObserver(
      function (entries) {
        entries.forEach(function (entry) {
          if (entry.isIntersecting) {
            var id = entry.target.id;
            navLinks.forEach(function (link) {
              link.classList.toggle(
                "active",
                link.getAttribute("href") === "#" + id
              );
            });
          }
        });
      },
      { rootMargin: "-45% 0px -50% 0px", threshold: 0 }
    );
    sections.forEach(function (section) {
      navObserver.observe(section);
    });
  }

  /* ---------------- FAQ (acordeão) ---------------- */
  var faqItems = $$(".faq-item");

  function openFaq(item) {
    var button = $(".faq-q", item);
    var panel = $(".faq-a", item);
    item.classList.add("open");
    if (button) button.setAttribute("aria-expanded", "true");
    if (!panel) return;
    panel.hidden = false;
    requestAnimationFrame(function () {
      panel.style.maxHeight = panel.scrollHeight + "px";
    });
  }

  function closeFaq(item) {
    if (!item.classList.contains("open")) return;
    var button = $(".faq-q", item);
    var panel = $(".faq-a", item);
    item.classList.remove("open");
    if (button) button.setAttribute("aria-expanded", "false");
    if (!panel) return;
    panel.style.maxHeight = panel.scrollHeight + "px";
    requestAnimationFrame(function () {
      panel.style.maxHeight = "0px";
    });
    setTimeout(function () {
      if (!item.classList.contains("open")) {
        panel.hidden = true;
      }
    }, 380);
  }

  faqItems.forEach(function (item) {
    var button = $(".faq-q", item);
    if (!button) return;
    button.addEventListener("click", function () {
      var wasOpen = item.classList.contains("open");
      faqItems.forEach(closeFaq);
      if (!wasOpen) {
        openFaq(item);
      }
    });
  });

  /* ---------------- Revelação suave ao rolar ---------------- */
  var revealElements = $$(".reveal");
  var reduceMotion = window.matchMedia(
    "(prefers-reduced-motion: reduce)"
  ).matches;

  if (reduceMotion || !("IntersectionObserver" in window)) {
    revealElements.forEach(function (el) {
      el.classList.add("in");
    });
  } else {
    var revealObserver = new IntersectionObserver(
      function (entries) {
        entries.forEach(function (entry) {
          if (entry.isIntersecting) {
            entry.target.classList.add("in");
            revealObserver.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.12, rootMargin: "0px 0px -40px 0px" }
    );
    revealElements.forEach(function (el) {
      revealObserver.observe(el);
    });
  }

  /* ---------------- Configurações complementares ---------------- */
  // E-mail de suporte no rodapé
  if (typeof SUPPORT_EMAIL === "string" && SUPPORT_EMAIL.trim() !== "") {
    var emailLink = $("#suporte-email");
    if (emailLink) {
      emailLink.textContent = SUPPORT_EMAIL.trim();
      emailLink.setAttribute("href", "mailto:" + SUPPORT_EMAIL.trim());
    }
  }

  // Ano do rodapé
  var yearElement = $("#ano");
  if (yearElement) {
    var customYear = typeof COPYRIGHT_YEAR === "string" ? COPYRIGHT_YEAR.trim() : "";
    yearElement.textContent = customYear !== "" ? customYear : String(new Date().getFullYear());
  }
})();
