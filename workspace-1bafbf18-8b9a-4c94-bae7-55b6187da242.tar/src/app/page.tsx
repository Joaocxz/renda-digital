import { redirect } from "next/navigation";

// Redireciona a rota raiz para a landing page estática RENDA DIGITAL
// (servida a partir de /public/renda-digital/index.html)
export default function Home() {
  redirect("/renda-digital/index.html");
}
